//
// Created by asma on 4/6/16.
//

#include <QtWidgets/qwidget.h>
#include <QtNetwork/qtcpserver.h>
#include<QLabel>
#include <vector>

#ifndef MESSENGER_SERVER_SERVER_H
#define MESSENGER_SERVER_SERVER_H

using namespace std;


class Server : public QWidget
{
    Q_OBJECT
public :
    explicit Server(QWidget* = 0);


private slots:
    void connectServer();
    void exchangeData();


private:
    QLabel *namel;
    QLabel *serverl;
    QLabel *portl;
    QTcpServer *m_server;
    vector<QTcpSocket *> *c_socket;
    QHostAddress ipAdress;
    void startServer();
};


#endif //MESSENGER_SERVER_SERVER_H
