//
// Created by asma on 4/6/16.
//
#include <QtNetwork/qtcpsocket.h>
#include <QTcpServer>
#include <QtWidgets>
#include <QMessageBox>
#include<QLabel>
#include <iostream>
#include "Server.h"

using namespace std;

static quint16 PORT_NUMBER = 3737;
Server ::Server(QWidget *parent)
{
    this->setFixedSize(400, 250);
    QPalette pal (palette());
    pal.setColor(QPalette :: Background ,QColor(255, 91, 71) );
    setAutoFillBackground(true);
    setPalette(pal);

    //namel = new QLabel ("chit-chat");
    namel = new QLabel("chit-chat", this);
    namel -> setFont(QFont("Purisa", 30));
    namel -> setGeometry(80,50,200,50);


    serverl = new QLabel("server", this);
    serverl -> setFont(QFont("Purisa", 30));
    serverl -> setGeometry(120,90,200,50);

    portl = new QLabel("3737",this);
    portl ->  setFont(QFont("Purisa", 30));
    portl -> setGeometry(150,140,200,50);

    m_server = new QTcpServer;
    c_socket = new vector<QTcpSocket*>;
    ipAdress ="127.0.0.1";
    startServer();
    connect(m_server, SIGNAL(newConnection()), this,SLOT( connectServer()));

}

void Server ::startServer() {
    m_server -> listen(ipAdress, PORT_NUMBER);

   // if(! m_server -> listen()){
       // QMessageBox :: critical(this, tr("Server"), tr("Unabale to start server %1.").arg(m_server -> errorString()) );
      //  close();
        return;
    //}

}


void Server :: connectServer() {
    QPalette pal (palette());
    pal.setColor(QPalette :: Background ,QColor(255, 255, 255) );
    setAutoFillBackground(true);
    setPalette(pal);
   // std :: cout << "hellosudo" << std :: endl;
    QTcpSocket *socket = m_server -> nextPendingConnection();
    connect(socket, SIGNAL(readyRead()), this, SLOT(exchangeData()));
    c_socket -> push_back(socket);
}

void Server ::exchangeData() {

    QString message;
    for (int i = 0; i < c_socket->size(); i++)
        if (c_socket->at(i)->bytesAvailable()) {
            message = c_socket->at(i)->readAll();
            break;
        }
    QByteArray data(message.toStdString().c_str());
    for (int i = 0; i < c_socket->size(); i++)
        c_socket->at(i)->write(data);
    std :: cout << "hello" << std :: endl;

}





