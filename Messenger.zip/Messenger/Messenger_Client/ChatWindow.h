//
// Created by asma on 4/12/16.
//
#include<QWidget>
#include<QTextEdit>
#include <QCheckBox>
#include <QtWidgets/qtextedit.h>
#include <QtWidgets/qpushbutton.h>
#include <QtNetwork/qhostaddress.h>
#include <QtNetwork/qtcpsocket.h>
#include <QtMultimedia/qmediaplayer.h>

#ifndef MESSENGER_CLIENT_CHATWINDOW_H
#define MESSENGER_CLIENT_CHATWINDOW_H


class ChatWindow  : public  QWidget
{
    Q_OBJECT

public:
    ChatWindow(QWidget *parent = 0);

private:
    QTcpSocket *client;
    QTextEdit *message;
    QTextEdit *chat;
    QPushButton *send;
    QCheckBox *notification;
    QString c_name;
    QHostAddress ipadress;
    QMediaPlayer *sound;

  private slots:
    void catchData();
    void exchangeData();


public:
    void setName(QString );
    void setIP(QString);
};


#endif //MESSENGER_CLIENT_CHATWINDOW_H
