#include <iostream>
#include <QtWidgets/qapplication.h>
#include "StartWindow.h"
#include "ChatWindow.h"

using namespace std;

int main(int argc, char **argv) {
    QApplication app(argc, argv);

    StartWindow window;
    window.show();

    return app.exec();

}