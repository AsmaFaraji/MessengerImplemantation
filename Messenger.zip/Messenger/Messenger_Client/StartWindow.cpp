//
// Created by asma on 4/11/16.
//

#include "StartWindow.h"
#include "ChatWindow.h"
#include <QWidget>
#include <QLabel>
#include <QPalette>
#include <QColor>
#include <QPushButton>
#include <QLineEdit>

StartWindow ::StartWindow(QWidget *parent) {
    setFixedSize(350, 600);

    QPalette pal (palette());
    pal.setColor(QPalette :: Background ,QColor(255, 91, 71) );
    setAutoFillBackground(true);
    setPalette(pal);

    titleL = new QLabel("chit-chat", this);
    titleL -> setFont(QFont("Purisa", 30));
    titleL -> setGeometry(80,50,200,50);

    my_IPL = new QLabel("IPAdd:", this);
    my_IPL ->  setFont( QFont( "lucida", 15, QFont::Bold,true));
    my_IPL -> setGeometry(45, 200, my_IPL -> sizeHint().width(), my_IPL -> sizeHint().height() );

    my_IPLE = new QLineEdit(this);
    my_IPLE -> setGeometry(50 + my_IPL -> sizeHint().width(), 200, my_IPLE -> sizeHint().width(), my_IPLE -> size().height() );
    my_IPLE -> setText("127.0.0.1");

    my_nameL = new QLabel("NAME:", this);
    my_nameL-> setFont(QFont("lucida", 15, QFont::Bold, true));
    my_nameL-> setGeometry(45, my_IPL->y() + 50 , my_IPL -> sizeHint().width(), my_IPL -> sizeHint().height() );

    my_nameLE = new QLineEdit(this);
    my_nameLE -> setGeometry(50 + my_nameL -> sizeHint().width(), my_IPL ->y() + 50, my_nameLE -> sizeHint().width(), my_nameLE -> sizeHint().height());
    my_nameLE -> setText("ASMA");

    startP = new QPushButton("START",this);
    startP -> setFont( QFont( "lucida", 15, QFont::Bold,true));
    startP -> setStyleSheet("background-color: rgb(255,255,0);");
    startP -> setGeometry(130, my_nameL->y() + 90, startP ->sizeHint().width(), startP -> sizeHint().height());

    connect(startP, SIGNAL(clicked()),this, SLOT(startChat()));





}
void StartWindow ::startChat() {
    close();
    chatWindow = new ChatWindow();
    chatWindow -> setName(my_nameLE->text());
    chatWindow -> setIP(my_IPLE -> text());
    chatWindow -> show();
}


