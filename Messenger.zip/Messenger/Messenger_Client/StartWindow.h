//
// Created by asma on 4/11/16.
//
#include <QWidget>
#include <QLabel>
#include <QPushButton>
#include <QLineEdit>
#include <QtWidgets/qlineedit.h>
#include "ChatWindow.h"

#ifndef MESSENGER_CLIENT_STARTWINDOW_H
#define MESSENGER_CLIENT_STARTWINDOW_H


class StartWindow : public QWidget
{
    Q_OBJECT
public:
    StartWindow(QWidget *parent = 0);

private:
  //  QLabel *my_port;
    QLabel *my_IPL;
    QLabel *titleL;
    QLabel *my_nameL;
    QPushButton *startP;
    QLineEdit *my_nameLE;
    QLineEdit *my_IPLE;
    ChatWindow *chatWindow;
private slots:
    void startChat();









};


#endif //MESSENGER_CLIENT_STARTWINDOW_H
