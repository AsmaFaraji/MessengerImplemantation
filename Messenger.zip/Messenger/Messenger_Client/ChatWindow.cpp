//
// Created by asma on 4/12/16.
//

#include "ChatWindow.h"
#include<QWidget>
#include<QTextEdit>
#include <QCheckBox>
#include <QtWidgets/qtextedit.h>
#include <QtWidgets/qpushbutton.h>
#include <iostream>
#include <string>
#include <QtCore/qfileinfo.h>

using namespace std;
ChatWindow ::ChatWindow(QWidget *parent)
{
    client = new QTcpSocket;
    sound = new QMediaPlayer(this);
    sound->setMedia(QUrl::fromLocalFile(QFileInfo("sounds-940-pizzicato.mp3").absoluteFilePath()));
    sound->setVolume(100);



    QPalette pal (palette());
    pal.setColor(QPalette :: Background ,QColor(255, 91, 71) );
    setAutoFillBackground(true);
    setPalette(pal);
    setFixedSize( 550, 550);

    chat = new QTextEdit(this);
    chat -> setGeometry(50, 30, 450, 400);

    message = new QTextEdit(this);
    message -> setGeometry(50, 450, 400, 50);

    send = new QPushButton("SEND", this);
    send -> setFont( QFont( "lucida", 15, QFont::Bold,true));
    send -> setGeometry(460, 450, 70, 50);
    connect(send, SIGNAL(clicked()), this, SLOT(exchangeData()));

    notification = new QCheckBox("NOTIFICATION", this);
    notification -> setCheckState(Qt::Checked);
    notification -> setGeometry(50, 10 , notification->sizeHint().width(), notification->sizeHint().height());
   // connect(notification,SIGNAL(clicked()), notification, SLOT(stateChanged()));

}
void ChatWindow ::setName(QString name) {
   c_name = name;
    setWindowTitle(c_name);

    //std::cout << "name" << std :: endl;
}
void ChatWindow ::setIP(QString host) {
    ipadress  = host;
    client -> connectToHost(ipadress, 3737);
    connect(client, SIGNAL(readyRead()), this, SLOT(catchData()));
    //std :: cout << host.toStdString() << std :: endl;
}
void ChatWindow ::catchData() {
    QString mess = client->readAll();
    chat->append(mess);
    QString hlp = "";
    for (int i = 0; mess.at(i + 1) != ':'; i++)
                hlp += mess.at(i);

    if (hlp != c_name && notification -> isChecked()) {
       sound -> play();
        // << "state''" << endl;
    }
    //std :: cout << "catched" << std :: endl;

}
 void ChatWindow ::exchangeData() {

     QString mess =c_name  + " : "+  message -> toPlainText() ;

     //std :: cout << mess.toStdString() << std :: endl;

     QByteArray data(mess.toStdString().c_str());
        if(message -> toPlainText() != "")
             client -> write(data);
     message -> clear();



 }